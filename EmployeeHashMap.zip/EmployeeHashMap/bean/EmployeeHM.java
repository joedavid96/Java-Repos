package com.capgemini.assignments.exercise7.EmployeeHashMap.bean;

public class EmployeeHM implements Comparable {

	private int id;
	private String name;
	private double salary;
	private String Designation;
	private String Scheme;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getDesignation() {
		return Designation;
	}
	public void setDesignation(String designation) {
		Designation = designation;
	}
	public String getScheme() {
		return Scheme;
	}
	public void setScheme(String scheme) {
		Scheme = scheme;
	}
	@Override
	public String toString() {
		return "\nID : " + id + "\nName = " + name + "\nSalary : " + salary + 
				"\nDesignation=" + Designation;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		EmployeeHM e1 = (EmployeeHM) obj;
		return id == e1.id;
	}
	
	public EmployeeHM(String name, double salary) {
		super();
		this.name = name;
		this.salary = salary;
	}
	
	public EmployeeHM(int id, String name, double salary, String designation) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		Designation = designation;
		
	}
	public EmployeeHM(int id) {
		super();
		this.id = id;
	}
	public EmployeeHM() {
		super();
	}
	@Override
	public int compareTo(Object obj) {
		
		EmployeeHM e2 = (EmployeeHM) obj;
		
		Double d = salary-e2.salary; 
		
		return d.intValue() ;
	}
	
	
	
}
