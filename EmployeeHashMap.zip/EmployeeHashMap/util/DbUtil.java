package com.capgemini.assignments.exercise7.EmployeeHashMap.util;

import java.util.ArrayList;
import java.util.HashMap;


import com.capgemini.assignments.exercise7.EmployeeHashMap.bean.EmployeeHM;

public class DbUtil {
	
	private ArrayList<EmployeeHM> list1 = new ArrayList<EmployeeHM>();
	private ArrayList<EmployeeHM> list2 = new ArrayList<EmployeeHM>();
	private ArrayList<EmployeeHM> list3 = new ArrayList<EmployeeHM>();
	private ArrayList<EmployeeHM> list4 = new ArrayList<EmployeeHM>();
	
	private HashMap<String,ArrayList<EmployeeHM>> list = new HashMap<String,ArrayList<EmployeeHM>>();
	
	public HashMap<String, ArrayList<EmployeeHM>> getList() {
		return list;
	}

	public void setList(HashMap<String, ArrayList<EmployeeHM>> list) {
		this.list = list;
	}
	
	public ArrayList<EmployeeHM> getList1() {
		return list1;
	}

	public void setList1(ArrayList<EmployeeHM> list1) {
		this.list1 = list1;
	}

	public ArrayList<EmployeeHM> getList2() {
		return list2;
	}

	public void setList2(ArrayList<EmployeeHM> list2) {
		this.list2 = list2;
	}

	public ArrayList<EmployeeHM> getList3() {
		return list3;
	}

	public void setList3(ArrayList<EmployeeHM> list3) {
		this.list3 = list3;
	}

	public ArrayList<EmployeeHM> getList4() {
		return list4;
	}

	public void setList4(ArrayList<EmployeeHM> list4) {
		this.list4 = list4;
	}

	
}
