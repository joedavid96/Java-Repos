package com.capgemini.assignments.exercise7.EmployeeHashMap.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.capgemini.assignments.exercise7.EmployeeHashMap.bean.EmployeeHM;
import com.capgemini.assignments.exercise7.EmployeeHashMap.exception.EHMException;
import com.capgemini.assignments.exercise7.EmployeeHashMap.model.EmpHashMapDAO;
import com.capgemini.assignments.exercise7.EmployeeHashMap.model.EmpHashMapDAOImpl;

public class EmpHashMapServiceImpl implements EmpHashMapService {
	
	private EmpHashMapDAO dao;
	
	private String [] sch = new String[] {"A","C","B","None"};
	
	public EmpHashMapServiceImpl() {
		
		dao = new EmpHashMapDAOImpl();
		
	}

	@Override
	public int addEmployee(EmployeeHM e) throws EHMException {
		
		if(e.getName()!= null && e.getSalary()!=0)
		{
			return dao.addEmployee(e);
		}
		
		else
		return -1;
	}

	@Override
	public  ArrayList<EmployeeHM> getEmployee(String scheme) throws EHMException {
		
		boolean flag = false;
		
		for(int i = 0; i<sch.length ; i++)
		{
			if(scheme.equalsIgnoreCase(sch[i]))
			{
				flag = true;
				break;
			}
			else
			{
				flag = false;
			}
			
		}
		if(flag)
		{
			return dao.getEmployee(scheme);
		}
		else 
			
			throw new EHMException("Invalid Scheme or ListEmpty");
	}

	@Override
	public boolean deleteEmployee(int empid) throws EHMException {

		if( empid!= 0 )
			return dao.deleteEmployee(empid);
		else
			throw new EHMException("Please enter an ID!!");
	}

	@Override
	public ArrayList<EmployeeHM> sortHashMap(String scheme) throws EHMException {
		
		return dao.sortHashMap(scheme);

	}

}
