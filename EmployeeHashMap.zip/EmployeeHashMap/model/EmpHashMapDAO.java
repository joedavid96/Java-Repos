package com.capgemini.assignments.exercise7.EmployeeHashMap.model;

import java.util.ArrayList;
import java.util.HashMap;

import com.capgemini.assignments.exercise7.EmployeeHashMap.bean.EmployeeHM;
import com.capgemini.assignments.exercise7.EmployeeHashMap.exception.EHMException;

public interface EmpHashMapDAO {
	
	public int addEmployee(EmployeeHM e) throws EHMException;
	
	public  ArrayList<EmployeeHM> getEmployee(String scheme) throws EHMException;
	
	public boolean deleteEmployee(int empid) throws EHMException;
	
	public ArrayList<EmployeeHM> sortHashMap(String scheme) throws EHMException;

}
