package com.capgemini.assignments.exercise7.EmployeeHashMap.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import com.capgemini.assignments.exercise7.EmployeeHashMap.bean.EmployeeHM;
import com.capgemini.assignments.exercise7.EmployeeHashMap.exception.EHMException;
import com.capgemini.assignments.exercise7.EmployeeHashMap.util.DbUtil;

public class EmpHashMapDAOImpl implements EmpHashMapDAO {
	
	private HashMap<String, ArrayList<EmployeeHM>> emp;
	
	private ArrayList<EmployeeHM> employeeA;
	private ArrayList<EmployeeHM> employeeB;
	private ArrayList<EmployeeHM> employeeC;
	private ArrayList<EmployeeHM> employeeNo;
	
	private DbUtil db = new DbUtil();
	
	private static int empID = 1480924;
	
	public EmpHashMapDAOImpl() {
		
		emp = db.getList();
		employeeA = db.getList1();
		employeeB = db.getList2();
		employeeC = db.getList3();
		employeeNo = db.getList4();
		
	}

	@Override
	public int addEmployee(EmployeeHM e) throws EHMException {
		
		double sal = e.getSalary();
		
		emp.
		
		if(sal>5000 && sal<20000)
		{
			e.setId(++empID);
			e.setDesignation("System Associate");
			e.setScheme("Scheme C");
			employeeC.add(e);
			emp.put("C", employeeC);
			
		}
		else if(sal>=20000 && sal<40000)
		{
			e.setId(++empID);
			e.setDesignation("Programmer");
			e.setScheme("Scheme B");
			employeeB.add(e);
			emp.put("B", employeeB);
			
		}
		else if(sal>=40000)
		{
			e.setId(++empID);
			e.setDesignation("Manager");
			e.setScheme("Scheme A");
			employeeA.add(e);
			emp.put("A", employeeA);
			
		}
		else if(sal<5000)
		{
			e.setId(++empID);
			e.setDesignation("Clerk");
			e.setScheme("No Scheme");
			employeeNo.add(e);
			emp.put("None", employeeNo);
			
		}
		
		return e.getId();
	}

	@Override
	public ArrayList<EmployeeHM> getEmployee(String scheme) throws EHMException {
		
		 return emp.get(scheme);
	}

	@Override
	public boolean deleteEmployee(int empid) throws EHMException {
		
		boolean flag = false;
		
		for(ArrayList<EmployeeHM> ehm : emp.values())
		{
			int index = ehm.indexOf( new EmployeeHM(empid) );
			if(index==-1)
			{
				flag = false;
			}
			else
			{
				EmployeeHM del = ehm.get(index);
				return ehm.remove(del);
			}
		}
				
		return flag;
	}

	@Override
	public ArrayList<EmployeeHM> sortHashMap(String scheme) throws EHMException {
	
//		for(ArrayList<EmployeeHM> ehm : emp.values())
//		{
//			List l = (List) ehm;
//			Collections.sort(l);
//			
//		}
		return emp.get(scheme);
	}

}
