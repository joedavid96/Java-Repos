package com.capgemini.assignments.exercise7.EmployeeHashMap.view;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

import com.capgemini.assignments.exercise7.EmployeeHashMap.bean.EmployeeHM;
import com.capgemini.assignments.exercise7.EmployeeHashMap.exception.EHMException;
import com.capgemini.assignments.exercise7.EmployeeHashMap.service.EmpHashMapService;
import com.capgemini.assignments.exercise7.EmployeeHashMap.service.EmpHashMapServiceImpl;

public class Client {
	
	private EmpHashMapService service;

	public Client() {
		
		service = new EmpHashMapServiceImpl();
	}
	
	public void menu()
	{
		int ch;
		Scanner sc = new Scanner(System.in);
		
		EmployeeHM e;
		
		System.out.println("Employee Medical Insurance Scheme");
		System.out.println("\nMenu:");
		System.out.println("1)Employee Registration");
		System.out.println("2)Get Employee Details");
		System.out.println("3)Delete Employee Profile");
		System.out.println("4)View Sorted List of Employees");
		System.out.println("5)Exit\n\n");
		System.out.println("Enter your choice: ");
		
		ch = sc.nextInt();
		
		switch(ch) 
		{
		case 1: System.out.println("Enter Employee Details");
		
				System.out.println("Name:");
				String name = sc.next();
		
				System.out.println("Salary:");
				double salary = sc.nextDouble();
		
				e = new EmployeeHM( name, salary);
				
				try {
					
					System.out.println("Employee Details Added Successfully. Your Employee ID is :" + service.addEmployee(e));
		
				}
				catch(EHMException e1)
				{
					e1.printStackTrace();
					
				}
				catch(Exception e1)
				{
					e1.printStackTrace();
				}
				
				break;
				
		case 2: System.out.println("Enter the Insurance Scheme to Retrieve Employee Profile {A,B,C,None} : ");
		
				String scheme = sc.next();
				
				try 
				{
					
					ArrayList<EmployeeHM> buffer = service.getEmployee(scheme);
					Iterator<EmployeeHM> it = buffer.iterator();
					
					while(it.hasNext())
					{
						System.out.println(it.next());
					}
					
				}
				catch (EHMException e1)
				{
					
					e1.printStackTrace();
					
				}
				catch(Exception e1)
				{
					
					e1.printStackTrace();
					
				}
				
				break;
				
		
		case 3 : System.out.println("Enter Employee ID whose profile is to be Deleted");
		
				 int eid = sc.nextInt();
				 
				try
				{
										
					if(service.deleteEmployee(eid))
					{
						System.out.println("Employee Profile Deleted Successfully!!");
					}
					
				}
				catch (EHMException e1)
				{
					
					e1.printStackTrace();
					
				}
				
				catch(Exception e1)
				{
					
					e1.printStackTrace();
					
				}
				
				break;
				
		
		case 4 : System.out.println("Sorted List of Employees:");
		
					System.out.println("Enter Scheme:" );
					String sch = sc.next();
					
				try
				{
					
					ArrayList<EmployeeHM> out = service.sortHashMap(sch);
					
//					Set s = out.entrySet();
					
					Iterator it = out.iterator();
					
					while(it.hasNext())
					{
						System.out.println(it.next());
					}
					
					
				} 
				catch (EHMException e1)
				{
					
					
					e1.printStackTrace();
					
					
				}
				catch(Exception e1)
				{
					
					e1.printStackTrace();
					
				}
				
				break;
				
		case 5: System.out.println("Thank You.");
		
				System.exit(0);
				
				break;
				
				
	   default: System.out.println("Invalid Option. Try Again.");
		
			    break;
		
				
	}

}
	
	public static void main(String[] args) {
		
		Client c = new Client();
		
		while(true)
			
			c.menu();
		
		
	}


}
