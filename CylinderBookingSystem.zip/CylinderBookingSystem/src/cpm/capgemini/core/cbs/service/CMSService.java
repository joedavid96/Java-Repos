package cpm.capgemini.core.cbs.service;

import cpm.capgemini.core.cbs.exception.CMSException;

public interface CMSService {
	
	public void viewAvailability() throws CMSException;
	
	public void BookCylinder(String AgencyName, int CylinderCount) throws CMSException;

}
