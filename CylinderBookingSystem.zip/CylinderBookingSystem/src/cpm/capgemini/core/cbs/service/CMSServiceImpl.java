package cpm.capgemini.core.cbs.service;


import cpm.capgemini.core.cbs.exception.CMSException;
import cpm.capgemini.core.cbs.model.CMSModel;
import cpm.capgemini.core.cbs.model.CMSModelImpl;

public class CMSServiceImpl implements CMSService {
	
	private CMSModel cmsDAO;
	
	public CMSServiceImpl()
	{
		
		cmsDAO = new CMSModelImpl();
		
	}
	
	public CMSServiceImpl(CMSModel cmsDAO)
	{
		
		cmsDAO = new CMSModelImpl();
		
	}

	@Override
	public void viewAvailability() throws CMSException {
		
		 cmsDAO.viewAvailability();
		
	}

	@Override
	public void BookCylinder(String AgencyName, int CylinderCount) throws CMSException {
		
		if(AgencyName.isEmpty() || CylinderCount==0)
		{
			
			System.out.println("Agency Name or Cylinder Count is Invalid!");
			
		}
		else
		cmsDAO.BookCylinder(AgencyName, CylinderCount);
		

	}

}
