package cpm.capgemini.core.cbs.bean;

public class Cylinder {
	
	private String AgencyName;
	private String Location;
	private int CylinderCount;
	
	//hashcode and equals
	
//	@Override
//	public int hashCode() {
//		final int prime = 31;
//		int result = 1;
//		result = prime * result + ((AgencyName == null) ? 0 : AgencyName.hashCode());
//		return result;
//	}
//
//	@Override
//	public boolean equals(Object obj) 
//	{
//		
//		Cylinder cl = (Cylinder) obj;
//		
//		return AgencyName.equalsIgnoreCase(cl.AgencyName);
//		
//	}

	
	//toString
	
	@Override
	public String toString() {
		return  AgencyName + "\t\t\t" + Location + "\t\t\t" + CylinderCount;
	}
	
	//getters and setters
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((AgencyName == null) ? 0 : AgencyName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cylinder other = (Cylinder) obj;
		if (AgencyName == null) {
			if (other.AgencyName != null)
				return false;
		} else if (!AgencyName.equals(other.AgencyName))
			return false;
		return true;
	}

	public String getAgencyName() {
		return AgencyName;
	}
	public void setAgencyName(String agencyName) {
		AgencyName = agencyName;
	}
	public String getLocation() {
		return Location;
	}
	public void setLocation(String location) {
		Location = location;
	}
	public int getCylinderCount() {
		return CylinderCount;
	}
	public void setCylinderCount(int cylinderCount) {
		CylinderCount = cylinderCount;
	}
	
	//constructors
	
	
	
	public Cylinder() {
		super();
	}
		
	public Cylinder(String agencyName) {
		super();
		AgencyName = agencyName;
	}
	public Cylinder(String agencyName, String location, int cylinderCount) {
		super();
		AgencyName = agencyName;
		Location = location;
		CylinderCount = cylinderCount;
	}
	
	
	
	
	
	

}
