package cpm.capgemini.core.cbs.util;

import java.util.ArrayList;
import java.util.List;

import cpm.capgemini.core.cbs.bean.Cylinder;

public class CMSUtil {
 
	private List<Cylinder> cylinders = new ArrayList<Cylinder>();

	{
		
		cylinders.add( new Cylinder("Jyothi", "Mumbai", 45) );
		cylinders.add( new Cylinder("HP", "Pune", 12) );
		cylinders.add( new Cylinder("NewHP", "Chennai", 34) );
		
	}

	public List<Cylinder> getCylinders() {
		return cylinders;
	}

	public void setCylinders(List<Cylinder> cylinders) {
		this.cylinders = cylinders;
	}
	

}
