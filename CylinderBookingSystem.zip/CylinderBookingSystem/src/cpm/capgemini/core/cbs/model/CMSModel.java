package cpm.capgemini.core.cbs.model;

import cpm.capgemini.core.cbs.exception.CMSException;

public interface CMSModel {
	
	public void viewAvailability () throws CMSException;
	
	public void BookCylinder(String AgencyName, int CylinderCount) throws CMSException;
	

}
