package cpm.capgemini.core.cbs.model;

import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import cpm.capgemini.core.cbs.bean.Cylinder;
import cpm.capgemini.core.cbs.exception.CMSException;
import cpm.capgemini.core.cbs.util.CMSUtil;

public class CMSModelImpl implements CMSModel {
	
	private List<Cylinder> cylinder;
	private CMSUtil cmsUtil = new CMSUtil();
	private static int bkid = 3459871;
	
	static Logger myLogger = Logger.getLogger(CMSModelImpl.class);
	
	public CMSModelImpl()
	{
		cylinder = cmsUtil.getCylinders();
	}

	@Override
	public void viewAvailability() throws CMSException {
		
		PropertyConfigurator.configure("log4j.properties");
		
		myLogger.info("viewAvailability Method Called");
		
		myLogger.debug("Method Takes in NO Arguments");
		
		System.out.println("Agency Name\t\tLocation\t\tCylinder Count");
		for(int i=0; i<cylinder.size();i++)
		{
			System.out.println(cylinder.get(i));
			
		}
	
	}

	@Override
	public void BookCylinder(String AgencyName, int CylinderCount) throws CMSException {
		
		PropertyConfigurator.configure("log4j.properties");
		
		myLogger.info("BookCylinder Method Called");
		myLogger.debug("Method called with arguments" + AgencyName + " and " + CylinderCount); 
		
		int index = cylinder.indexOf( new Cylinder(AgencyName));
		if(index == -1)
		{
			myLogger.error("Exception raised as argument passed is invalid = " + AgencyName);
			System.out.println("Supplier with Name" + "'" +AgencyName + "'" + "not Found!\n\n");
			
		}
		else 
		{
			Cylinder cy = cylinder.get(index);
			int count = cy.getCylinderCount();
			if(count-CylinderCount<0)
			{
				myLogger.debug("Method called with argument " + CylinderCount);
				System.out.println("Sorry..The requested  number of cylinders  are unavailable at the requested location. \n Please try another location. Thanks.\n\n");
			}
			else 
			{
				myLogger.warn("Attempting to book cylinders!");
				cy.setCylinderCount(count-CylinderCount);
				System.out.println("Thank You! Your Booking ID is " + bkid++ +". Cylinders will be dispatched soon. Have a great day!\n\n");
			}
			
			
		}
		
		

	}

}
