package cpm.capgemini.core.cbs.view;

import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import cpm.capgemini.core.cbs.exception.CMSException;
import cpm.capgemini.core.cbs.service.CMSService;
import cpm.capgemini.core.cbs.service.CMSServiceImpl;

public class Customer {
	
	private CMSService cylservice;
	
	public Customer()
	{
		
		cylservice = new CMSServiceImpl();
		
	}
	
	public void menu()
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("\nCylinder Booking System\n\n");
		System.out.println("Menu:\n");
		System.out.println("1)View Availability");
		System.out.println("2)Make a Booking");
		System.out.println("3)Exit\n");
		System.out.println("Enter Your Choice:");
		
		int ch = sc.nextInt();
		
		switch(ch)
		{
		case 1: 
			
			
			try {
				
				cylservice.viewAvailability();
				
				} 
				catch (CMSException e)
				{
					
					e.printStackTrace();
					
				}
				catch(Exception e)
				{
					
					e.printStackTrace();
						
				}
				
				break;
		
		case 2: 
			
				System.out.println("Enter Agency Name:");
				String name = sc.next();
				
				System.out.println("Enter Cylinder Count:");
				int count = sc.nextInt();
				
				try
				{
				
					cylservice.BookCylinder(name, count);
										
				}
				catch(CMSException e)
				{
					
					e.printStackTrace();
					
				}
				catch(Exception e)
				{
					
					e.printStackTrace();
					
				}
				
			
				break;
	
		case 3: System.out.println("Thank you for using our Service! Have a nice Day!");
		
				System.exit(0);
				
		
		default: System.out.println();
			
				break;
		
		}
		
		
		
	}
	
	
	

	public static void main(String[] args) {
		
		PropertyConfigurator.configure("log4j.properties");
	
		Customer c = new Customer();
		
		while(true)
			c.menu();
		

	}

}
